import React from 'react';


function Contact(){
  return(
    <div className = 'contact-body'>
    Contact us
    </div>
  )
}


export default Contact